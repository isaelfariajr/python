name = 'Brandon Krakowsky'

#get index of single space between first name and last name
first_space = name.index(' ')

#get substring of name using slice
#first name only
print(name[0:first_space])