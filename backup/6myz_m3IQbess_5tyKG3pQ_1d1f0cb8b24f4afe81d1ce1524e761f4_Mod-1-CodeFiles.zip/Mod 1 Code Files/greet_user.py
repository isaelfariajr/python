"""This code will:
Prompt for your name
Set the 'name' variable
Print a message"""
name = input("What is your name?") #gets the user's name
print("Hello " + name) #prints a message with the user's name
