s = 'Hello world!'

#get substring using slice
print(s[:5]) #characters 1 - 5

