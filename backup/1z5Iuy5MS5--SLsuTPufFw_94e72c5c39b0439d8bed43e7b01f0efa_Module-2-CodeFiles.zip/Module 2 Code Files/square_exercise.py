def square(x):
    y = x * x
    return y

result = square(10)
print(result)
