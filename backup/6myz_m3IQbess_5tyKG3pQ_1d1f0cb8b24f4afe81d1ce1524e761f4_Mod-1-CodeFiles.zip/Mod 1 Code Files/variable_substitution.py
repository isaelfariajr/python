x = y = 10
z = 2 * x + y
print(z)

z = z ** (y - 1)
print(z)

x = 42
b = 15 < (x / 2) < 25
print(b)
print(type(b))

x = 42
y = str(x)
x *= 2 #same as x = x * 2
y *= 2 #same as y = y * 2
print(x)
print(y)
