age = int(input("How old are you?"))
print(type(age))

#calculate age in 3 years
print(age + 3)

