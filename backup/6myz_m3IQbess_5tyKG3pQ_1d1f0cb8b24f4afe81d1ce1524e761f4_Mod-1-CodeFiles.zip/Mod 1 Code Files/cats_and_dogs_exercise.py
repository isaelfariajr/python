#set a variable x to "cats"
x = 'cats'

#set a variable y to "dogs"
y = 'dogs'

#referencing the variables above, set a new variable s to "It's raining cats and dogs!"
s = "It's raining " + x + " and " + y + "!"

#print s
print(s)

