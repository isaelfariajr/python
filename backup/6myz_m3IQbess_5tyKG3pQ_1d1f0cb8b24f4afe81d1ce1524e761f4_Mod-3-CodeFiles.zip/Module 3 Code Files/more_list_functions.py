ls1 = [2, 3, 4]
ls2 = [7, 8, 9]

ls1.extend(ls2)

for l in ls1:
    print(l)