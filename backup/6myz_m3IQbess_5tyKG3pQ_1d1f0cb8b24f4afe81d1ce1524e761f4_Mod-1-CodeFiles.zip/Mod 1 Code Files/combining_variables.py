fav_movie = "Justin Bieber's Believe"
fav_singer = "Justin Bieber"

favs = "Your favorite movie is " + fav_movie + " and your favorite singer is " + fav_singer
print(favs)
