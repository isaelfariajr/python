fav_movie = input("What is your favorite movie?")
fav_singer = input("Who is your favorite singer?")

favs = "Your favorite movie is {} and your favorite singer is {}".format(fav_movie, fav_singer)
print(favs)
