#exit a loop using break
x = 1
while x <= 10:
    if x == 5:
        break #this will break out of the loop immediately

    print(x)
    x += 1
