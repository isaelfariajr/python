month = "February"
print(month, "is spelled:")

for x in month:
    print(x, end = ' ')
